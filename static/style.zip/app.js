/**
 * Antigravity RAG System - Redesigned Frontend logic matching React Spec
 */

// --- Global App State ---
const State = {
    apiKey: '',
    embeddingModel: 'openai/text-embedding-3-small',
    generationModel: 'google/gemini-2.5-flash',
    temperature: 0.5,
    topK: 5,
    hybridWeight: 0.5,
    
    indexed: false,
    chatHistory: [],
    conversations: {}, // Local database of past conversation sessions
    currentSessionId: null,
    isIndexingActive: false,
    indexingIntervalId: null
};

// --- DOM Element Mappings ---
const DOM = {
    // Navigation & Layout
    navTabs: document.getElementById('navigation-tabs'),
    tabBtns: document.querySelectorAll('.nav-btn'),
    viewPanels: document.querySelectorAll('.view-panel'),
    globalStatusBadge: document.getElementById('global-status-badge'),
    globalStatusText: document.getElementById('global-status-text'),
    workspaceTitle: document.getElementById('workspace-title'),
    workspaceSubtitle: document.getElementById('workspace-subtitle'),
    
    // Global Indexing Alert Panel
    globalIndexingPanel: document.getElementById('global-indexing-panel'),
    alertTitleText: document.getElementById('alert-title-text'),
    alertProgressFill: document.getElementById('alert-progress-fill'),
    alertProgressPercent: document.getElementById('alert-progress-percentage'),
    
    // Sidebar Chat actions
    btnNewChat: document.getElementById('btn-new-chat'),
    recentChatsList: document.getElementById('recent-chats-list'),
    btnExportChat: document.getElementById('btn-export-chat'),
    activeModelBadge: document.getElementById('active-model-badge'),
    
    // Tab 1: Chat Assistant
    chatScroller: document.getElementById('chat-history-container'),
    chatForm: document.getElementById('chat-input-form'),
    chatInput: document.getElementById('chat-input-textarea'),
    chatSendBtn: document.getElementById('chat-send-btn'),
    
    // Tab 2: Document Indexer Dashboard
    idxStatPdf: document.getElementById('idx-stat-pdf'),
    idxStatIndexed: document.getElementById('idx-stat-indexed'),
    idxStatPages: document.getElementById('idx-stat-pages'),
    idxStatChunks: document.getElementById('idx-stat-chunks'),
    idxStatFaiss: document.getElementById('idx-stat-faiss'),
    idxStatVocab: document.getElementById('idx-stat-vocab'),
    indexerConfigForm: document.getElementById('indexer-config-form'),
    configChunkSize: document.getElementById('config-chunk-size'),
    configChunkOverlap: document.getElementById('config-chunk-overlap'),
    startIndexingBtn: document.getElementById('start-indexing-btn'),
    
    // Tab 3: Search Explorer
    explorerSearchForm: document.getElementById('explorer-search-form'),
    explorerSearchInput: document.getElementById('explorer-search-input'),
    explorerResultsGrid: document.getElementById('explorer-results-grid'),
    resultsCountBanner: document.getElementById('results-count-banner'),
    resultsCountText: document.getElementById('results-count-text'),
    
    // Tab 4: API Settings
    settingsForm: document.getElementById('settings-config-form'),
    settingsApiKey: document.getElementById('settings-api-key'),
    settingsEmbedModel: document.getElementById('settings-embed-model'),
    settingsGenModel: document.getElementById('settings-gen-model'),
    settingsTopK: document.getElementById('settings-top-k'),
    lblTopK: document.getElementById('lbl-top-k'),
    settingsTemperature: document.getElementById('settings-temperature'),
    lblTemperature: document.getElementById('lbl-temperature'),
    settingsHybridWeight: document.getElementById('settings-hybrid-weight'),
    lblHybridWeight: document.getElementById('lbl-hybrid-weight'),
    toggleKeyVisibility: document.getElementById('toggle-key-visibility'),
    saveSettingsBtn: document.getElementById('save-settings-btn'),
    
    // Tab 2 Document Upload Elements
    docUploadInput: document.getElementById('document-upload-input'),
    uploadDocBtn: document.getElementById('upload-doc-btn'),
    uploadFileLabel: document.getElementById('upload-file-label'),
    uploadStatusMsg: document.getElementById('upload-status-message'),
    chatAttachBtn: document.getElementById('chat-attach-btn')
};

// --- Initialization ---
document.addEventListener('DOMContentLoaded', () => {
    loadLocalSettings();
    loadConversationsDB();
    bindEvents();
    checkServerStatus(true); // Initial server check, sync saved configuration
    startStatusPolling(); // Poll indexing state periodically
});

// --- Settings Management (Local Storage) ---
function loadLocalSettings() {
    State.apiKey = localStorage.getItem('rag_api_key') || '';
    State.embeddingModel = localStorage.getItem('rag_embed_model') || 'openai/text-embedding-3-small';
    State.generationModel = localStorage.getItem('rag_gen_model') || 'google/gemini-2.5-flash';
    State.temperature = parseFloat(localStorage.getItem('rag_temperature')) || 0.5;
    State.topK = parseInt(localStorage.getItem('rag_top_k')) || 5;
    State.hybridWeight = parseFloat(localStorage.getItem('rag_hybrid_weight')) || 0.5;
    
    // Populate form elements
    DOM.settingsApiKey.value = State.apiKey;
    DOM.settingsEmbedModel.value = State.embeddingModel;
    DOM.settingsGenModel.value = State.generationModel;
    
    DOM.settingsTopK.value = State.topK;
    DOM.lblTopK.textContent = State.topK;
    
    DOM.settingsTemperature.value = State.temperature;
    DOM.lblTemperature.textContent = State.temperature.toFixed(1);
    
    DOM.settingsHybridWeight.value = State.hybridWeight;
    DOM.lblHybridWeight.textContent = State.hybridWeight.toFixed(1);
    
    updateHeaderBadge();
}

function saveLocalSettings() {
    localStorage.setItem('rag_api_key', State.apiKey);
    localStorage.setItem('rag_embed_model', State.embeddingModel);
    localStorage.setItem('rag_gen_model', State.generationModel);
    localStorage.setItem('rag_top_k', State.topK);
    localStorage.setItem('rag_temperature', State.temperature);
    localStorage.setItem('rag_hybrid_weight', State.hybridWeight);
    
    updateHeaderBadge();
}

function updateHeaderBadge() {
    const shortName = State.generationModel.split('/').pop();
    DOM.activeModelBadge.textContent = `${shortName} · Online`;
}

// --- Local Chat Log Database (conversations list) ---
function loadConversationsDB() {
    const raw = localStorage.getItem('rag_conversations');
    if (raw) {
        try {
            State.conversations = JSON.parse(raw);
        } catch (e) {
            console.error('Error parsing conversations database:', e);
            State.conversations = {};
        }
    } else {
        State.conversations = {};
    }
    
    renderConversationsList();
    
    // Auto-load most recent session if exists, otherwise start a new one
    const sessionIds = Object.keys(State.conversations);
    if (sessionIds.length > 0) {
        // Sort by timestamp modified descending
        sessionIds.sort((a, b) => State.conversations[b].timestamp - State.conversations[a].timestamp);
        loadConversation(sessionIds[0]);
    } else {
        startNewConversation();
    }
}

function renderConversationsList() {
    DOM.recentChatsList.innerHTML = '';
    const sessionIds = Object.keys(State.conversations);
    
    if (sessionIds.length === 0) {
        DOM.recentChatsList.innerHTML = `<div class="text-xs text-slate-500 italic py-2 px-2">No conversations saved</div>`;
        return;
    }
    
    // Sort by modified timestamp
    sessionIds.sort((a, b) => State.conversations[b].timestamp - State.conversations[a].timestamp);
    
    sessionIds.forEach(id => {
        const item = State.conversations[id];
        const isActive = id === State.currentSessionId;
        
        const chatRow = document.createElement('button');
        chatRow.className = `group text-left rounded-lg text-sm leading-5 flex p-2 items-center justify-between gap-2 w-full transition cursor-pointer select-none ${
            isActive ? 'bg-neutral-800 text-neutral-50 font-medium' : 'text-[#a1a1a1] hover:text-neutral-50 hover:bg-neutral-900/40'
        }`;
        
        // Dynamic event trigger
        chatRow.addEventListener('click', () => loadConversation(id));
        
        chatRow.innerHTML = `
            <div class="truncate flex-grow flex items-center gap-2 mr-2">
                <i class="fa-solid fa-message text-[#a1a1a1] text-xs size-4 flex items-center justify-center shrink-0"></i>
                <span class="truncate">${item.title}</span>
            </div>
            <span class="opacity-0 group-hover:opacity-100 text-[#a1a1a1] hover:text-red-400 p-0.5 rounded transition hover:bg-white/5 cursor-pointer delete-chat-btn" title="Delete conversation">
                <i class="fa-solid fa-trash-can text-[10px]"></i>
            </span>
        `;
        
        // Bind delete action
        const delBtn = chatRow.querySelector('.delete-chat-btn');
        delBtn.addEventListener('click', (e) => {
            e.stopPropagation(); // Prevent loading the conversation
            deleteConversation(id);
        });
        
        DOM.recentChatsList.appendChild(chatRow);
    });
}

function startNewConversation() {
    State.currentSessionId = `session-${Date.now()}`;
    State.chatHistory = [];
    
    // Clear scroller and append welcome splash
    DOM.chatScroller.innerHTML = `
        <div class="assistant-welcome flex justify-center items-center h-full py-10">
            <div class="welcome-card bg-neutral-900/60 border border-white/10 rounded-2xl p-8 text-center max-w-lg shadow-xl backdrop-blur-md animate-slideIn">
                <i class="fa-solid fa-graduation-cap text-4xl bg-gradient-to-r from-purple-500 to-sky-500 bg-clip-text text-transparent mb-5 inline-block animate-bounce"></i>
                <h2 class="text-lg font-bold text-white mb-2 font-heading">Welcome to your AI Teaching Assistant</h2>
                <p class="text-[#a1a1a1] text-sm mb-4 leading-relaxed font-medium">I am connected directly to your copy of the <strong>Artificial Intelligence: A Modern Approach (3rd ed.)</strong> textbook.</p>
                <p class="welcome-guide bg-white/2 border border-white/5 p-4 rounded-xl text-xs text-[#a1a1a1] leading-relaxed mb-6">Ask me academic questions, explain algorithms, or query specific concepts, and I will generate answers linked to precise page citations in the book.</p>
                
                <div class="suggested-queries flex flex-wrap justify-center gap-2">
                    <button class="suggestion-chip bg-sky-500/10 border border-sky-500/20 text-sky-300 hover:bg-sky-500/25 hover:border-sky-400 py-2 px-3.5 rounded-full text-xs font-semibold cursor-pointer transition hover:-translate-y-0.5" data-query="Explain what A* Search is and its heuristic requirements.">A* Search & Heuristics</button>
                    <button class="suggestion-chip bg-sky-500/10 border border-sky-500/20 text-sky-300 hover:bg-sky-500/25 hover:border-sky-400 py-2 px-3.5 rounded-full text-xs font-semibold cursor-pointer transition hover:-translate-y-0.5" data-query="What does PEAS stand for in Artificial Intelligence? Provide examples.">What is PEAS?</button>
                    <button class="suggestion-chip bg-sky-500/10 border border-sky-500/20 text-sky-300 hover:bg-sky-500/25 hover:border-sky-400 py-2 px-3.5 rounded-full text-xs font-semibold cursor-pointer transition hover:-translate-y-0.5" data-query="Define Markov Decision Processes (MDPs) and the Bellman Equation.">MDPs & Bellman Equation</button>
                </div>
            </div>
        </div>
    `;
    
    // Bind suggested queries clicks again in new container
    DOM.chatScroller.querySelectorAll('.suggestion-chip').forEach(chip => {
        chip.addEventListener('click', () => {
            const query = chip.dataset.query;
            DOM.chatInput.value = query;
            DOM.chatInput.focus();
            DOM.chatForm.requestSubmit();
        });
    });

    DOM.workspaceTitle.textContent = "New Conversation";
    DOM.btnExportChat.classList.add('hidden');
    
    // Reload sidebar highlight styles
    renderConversationsList();
}

function loadConversation(id) {
    if (!State.conversations[id]) return;
    
    State.currentSessionId = id;
    const session = State.conversations[id];
    State.chatHistory = session.messages;
    
    DOM.chatScroller.innerHTML = '';
    DOM.workspaceTitle.textContent = session.title;
    
    if (State.chatHistory.length === 0) {
        startNewConversation();
        return;
    }
    
    // Display all messages saved in this thread
    State.chatHistory.forEach(msg => {
        appendMessage(msg.role, msg.content, msg.metadata, false); // Append without saving again
    });
    
    DOM.btnExportChat.classList.remove('hidden');
    scrollToBottom();
    
    // Update sidebar dynamic highlights
    renderConversationsList();
}

function saveActiveConversation() {
    if (State.chatHistory.length === 0) return;
    
    // Determine active title based on first query
    let title = "New Conversation";
    const firstUserQuery = State.chatHistory.find(m => m.role === 'user');
    if (firstUserQuery) {
        title = firstUserQuery.content;
        if (title.length > 26) {
            title = title.substring(0, 24) + "...";
        }
    }
    
    State.conversations[State.currentSessionId] = {
        id: State.currentSessionId,
        title: title,
        messages: State.chatHistory,
        timestamp: Date.now()
    };
    
    localStorage.setItem('rag_conversations', JSON.stringify(State.conversations));
    DOM.workspaceTitle.textContent = title;
    DOM.btnExportChat.classList.remove('hidden');
    
    renderConversationsList();
}

function deleteConversation(id) {
    if (confirm("Are you sure you want to permanently delete this chat log?")) {
        delete State.conversations[id];
        localStorage.setItem('rag_conversations', JSON.stringify(State.conversations));
        
        if (State.currentSessionId === id) {
            // Active session deleted, restart new one
            startNewConversation();
        } else {
            renderConversationsList();
        }
    }
}

function exportChatLog() {
    if (State.chatHistory.length === 0) return;
    
    let md = `# Academic Q&A Log: Stuart Russell & Peter Norvig's AI Textbook\n`;
    md += `*Session ID: ${State.currentSessionId}*  \n`;
    md += `*Date Exported: ${new Date().toLocaleDateString()}*\n\n`;
    md += `---\n\n`;
    
    State.chatHistory.forEach(msg => {
        const roleLabel = msg.role === 'user' ? '### User Question' : '### AI Assistant Answer';
        md += `${roleLabel}\n\n${msg.content}\n\n`;
        
        if (msg.metadata && msg.metadata.retrieved_chunks && msg.metadata.retrieved_chunks.length > 0) {
            md += `*Retrieved Textbook Sources:*\n`;
            msg.metadata.retrieved_chunks.forEach(chunk => {
                md += `- **Page ${chunk.page_start}** (Match: ${Math.round(chunk.similarity_score * 100)}% | Sparse Score: ${chunk.sparse_score.toFixed(3)})\n`;
                md += `  > *"${chunk.text.substring(0, 200)}..."*\n`;
            });
            md += `\n`;
        }
        md += `---\n\n`;
    });
    
    // Download triggers
    const blob = new Blob([md], { type: 'text/markdown;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    
    const formattedTitle = DOM.workspaceTitle.textContent.toLowerCase().replace(/[^a-z0-9]+/g, '_');
    link.href = url;
    link.download = `rag_chat_${formattedTitle || 'log'}.md`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}

// --- Event Binding ---
function bindEvents() {
    // New chat action
    DOM.btnNewChat.addEventListener('click', startNewConversation);
    
    // Export action
    DOM.btnExportChat.addEventListener('click', exportChatLog);

    // Tab routing button actions
    DOM.navTabs.addEventListener('click', (e) => {
        const btn = e.target.closest('.nav-btn');
        if (!btn) return;
        switchTab(btn.dataset.tab, btn);
    });

    // Toggle API Key visibility
    DOM.toggleKeyVisibility.addEventListener('click', () => {
        const input = DOM.settingsApiKey;
        const icon = DOM.toggleKeyVisibility.querySelector('i');
        if (input.type === 'password') {
            input.type = 'text';
            icon.className = 'fa-solid fa-eye';
        } else {
            input.type = 'password';
            icon.className = 'fa-solid fa-eye-slash';
        }
    });

    // Sliders dynamic value labels
    DOM.settingsTopK.addEventListener('input', (e) => {
        DOM.lblTopK.textContent = e.target.value;
    });
    
    DOM.settingsTemperature.addEventListener('input', (e) => {
        DOM.lblTemperature.textContent = parseFloat(e.target.value).toFixed(1);
    });
    
    DOM.settingsHybridWeight.addEventListener('input', (e) => {
        DOM.lblHybridWeight.textContent = parseFloat(e.target.value).toFixed(1);
    });

    // Forms handles
    DOM.settingsForm.addEventListener('submit', handleSettingsSubmit);
    DOM.indexerConfigForm.addEventListener('submit', handleIndexingSubmit);
    DOM.explorerSearchForm.addEventListener('submit', handleExplorerSearchSubmit);
    DOM.chatForm.addEventListener('submit', handleChatSubmit);

    // Send on Enter (and Shift+Enter for newline)
    DOM.chatInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            // Dispatch a standard cancelable submit event to trigger handleChatSubmit reliably in any browser
            const submitEvent = new Event('submit', { cancelable: true, bubbles: true });
            DOM.chatForm.dispatchEvent(submitEvent);
        }
    });

    // Document Upload Bindings
    if (DOM.docUploadInput) {
        DOM.docUploadInput.addEventListener('change', handleFileUploadChange);
    }
    if (DOM.uploadDocBtn) {
        DOM.uploadDocBtn.addEventListener('click', handleDocUploadSubmit);
    }
    if (DOM.chatAttachBtn) {
        DOM.chatAttachBtn.addEventListener('click', () => {
            const indexerTab = document.getElementById('tab-btn-indexer');
            if (indexerTab) switchTab('indexer-view', indexerTab);
        });
    }
}

// --- Tab Routing View Changer (Redesigned with React Specs classes) ---
function switchTab(viewId, activeBtn) {
    // 1. Reset inactive styles on all tabs
    DOM.tabBtns.forEach(btn => {
        btn.className = "nav-btn flex items-center justify-start gap-2 hover:bg-neutral-800 text-[#a1a1a1] hover:text-neutral-50 py-2 px-3 rounded-lg text-sm w-full transition cursor-pointer";
    });
    
    // 2. Set active design styles on selected button
    activeBtn.className = "nav-btn flex items-center justify-start gap-2 bg-neutral-800 text-neutral-50 py-2 px-3 rounded-lg text-sm w-full transition cursor-pointer active-tab-btn";

    // 3. Hide all views & show target
    DOM.viewPanels.forEach(panel => panel.classList.add('hidden'));
    document.getElementById(viewId).classList.remove('hidden');

    // 4. Update Workspace headers
    switch (viewId) {
        case 'chat-view':
            // Restore active conversation title
            if (State.chatHistory.length > 0) {
                DOM.workspaceTitle.textContent = State.conversations[State.currentSessionId]?.title || "Chat Assistant";
                DOM.btnExportChat.classList.remove('hidden');
            } else {
                DOM.workspaceTitle.textContent = "New Conversation";
                DOM.btnExportChat.classList.add('hidden');
            }
            break;
        case 'indexer-view':
            DOM.workspaceTitle.textContent = "Document Index Control Dashboard";
            DOM.btnExportChat.classList.add('hidden');
            break;
        case 'explorer-view':
            DOM.workspaceTitle.textContent = "Vector Retrieval Explorer";
            DOM.btnExportChat.classList.add('hidden');
            break;
        case 'settings-view':
            DOM.workspaceTitle.textContent = "API Credentials & Settings Control";
            DOM.btnExportChat.classList.add('hidden');
            break;
    }
}

// --- Server Checks & State Polls ---

async function checkServerStatus(syncConfig = false) {
    try {
        const response = await fetch('/api/status');
        if (!response.ok) throw new Error('API status call failed');
        const data = await response.json();
        
        State.indexed = data.indexed;
        
        // Status Badge Style updates
        updateStatusBadge(data.indexed, data.active_indexing.status);
        
        // Update Document Indexer metrics
        updateIndexerDashboard(data);
        
        // Update active background indexing banner progress
        handleIndexingBanner(data.active_indexing);

        // Sync local settings with backend on startup
        if (syncConfig && State.apiKey) {
            syncSettingsWithServer();
        }
    } catch (error) {
        console.error('Server status sync error:', error);
        updateStatusBadge(false, 'offline');
    }
}

function updateStatusBadge(isIndexed, currentIndexingStatus) {
    DOM.globalStatusBadge.className = 'flex items-center gap-1.5 text-[9px] font-bold uppercase tracking-wider px-2 py-0.5 rounded border border-white/5 transition';
    
    if (['extracting', 'chunking', 'vectorizing', 'indexing'].includes(currentIndexingStatus)) {
        DOM.globalStatusBadge.classList.add('text-sky-400', 'bg-sky-500/5', 'border-sky-500/10');
        DOM.globalStatusText.innerHTML = `<i class="fa-solid fa-sync fa-spin"></i> Indexing...`;
    } else if (isIndexed) {
        DOM.globalStatusBadge.classList.add('text-emerald-400', 'bg-emerald-500/5', 'border-emerald-500/10');
        DOM.globalStatusText.textContent = "Index Ready";
    } else {
        DOM.globalStatusBadge.classList.add('text-amber-500', 'bg-amber-500/5', 'border-amber-500/10');
        DOM.globalStatusText.textContent = "Index Offline";
    }
}

function updateIndexerDashboard(data) {
    // PDF detection
    if (data.pdf_loaded) {
        DOM.idxStatPdf.className = 'text-sm font-semibold text-emerald-400';
        DOM.idxStatPdf.innerHTML = `<i class="fa-solid fa-circle-check mr-1.5"></i>AI.pdf Available`;
    } else {
        DOM.idxStatPdf.className = 'text-sm font-semibold text-red-400';
        DOM.idxStatPdf.innerHTML = `<i class="fa-solid fa-circle-xmark mr-1.5"></i>AI.pdf Missing`;
    }

    // Index active detection
    if (data.indexed) {
        DOM.idxStatIndexed.className = 'text-sm font-semibold text-emerald-400';
        DOM.idxStatIndexed.innerHTML = `<i class="fa-solid fa-circle-check mr-1.5"></i>Index Active`;
    } else if (['extracting', 'chunking', 'vectorizing', 'indexing'].includes(data.active_indexing.status)) {
        DOM.idxStatIndexed.className = 'text-sm font-semibold text-sky-400 animate-pulse';
        DOM.idxStatIndexed.innerHTML = `<i class="fa-solid fa-sync fa-spin mr-1.5"></i>Training...`;
    } else {
        DOM.idxStatIndexed.className = 'text-sm font-semibold text-slate-500';
        DOM.idxStatIndexed.textContent = "Not Indexed";
    }

    // Data Numbers
    DOM.idxStatPages.textContent = data.total_pages;
    DOM.idxStatChunks.textContent = data.total_chunks;
    DOM.idxStatVocab.textContent = `${data.vocabulary_size} words`;
    
    const faissMb = (data.faiss_size_bytes / (1024 * 1024)).toFixed(2);
    DOM.idxStatFaiss.textContent = `${faissMb} MB`;
    
    // Disable action buttons if active or missing PDF
    DOM.startIndexingBtn.disabled = !data.pdf_loaded || ['extracting', 'chunking', 'vectorizing', 'indexing'].includes(data.active_indexing.status);
}

function handleIndexingBanner(activeIndexing) {
    const activeStages = ['extracting', 'chunking', 'vectorizing', 'indexing'];
    if (activeStages.includes(activeIndexing.status)) {
        DOM.globalIndexingPanel.classList.remove('hidden');
        State.isIndexingActive = true;
        
        let labelText = "Processing textbook... ";
        if (activeIndexing.status === 'extracting') {
            labelText = `Extracting book pages: Page ${activeIndexing.pages_processed}/${activeIndexing.total_pages}`;
        } else if (activeIndexing.status === 'chunking') {
            labelText = "Structuring text page sliding window chunks...";
        } else if (activeIndexing.status === 'vectorizing') {
            labelText = `Generating dense embeddings: Vector ${activeIndexing.current_chunk}/${activeIndexing.total_chunks}`;
        } else if (activeIndexing.status === 'indexing') {
            labelText = "Structuring vector space inside local FAISS flat index...";
        }
        
        DOM.alertTitleText.textContent = labelText;
        DOM.alertProgressFill.style.width = `${activeIndexing.progress}%`;
        DOM.alertProgressPercent.textContent = `${activeIndexing.progress}%`;
    } else {
        DOM.globalIndexingPanel.classList.add('hidden');
        if (State.isIndexingActive) {
            State.isIndexingActive = false;
            checkServerStatus(false);
        }
    }
}

async function syncSettingsWithServer() {
    if (!State.apiKey) return;
    try {
        const res = await fetch('/api/settings', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                apiKey: State.apiKey,
                embeddingModel: State.embeddingModel,
                generationModel: State.generationModel,
                temperature: State.temperature,
                topK: State.topK,
                hybridWeight: State.hybridWeight
            })
        });
        if (!res.ok) console.warn('Failed to sync settings with FastAPI server');
    } catch (e) {
        console.error('Settings auto sync error:', e);
    }
}

function startStatusPolling() {
    setInterval(() => {
        checkServerStatus(false);
    }, 2000);
}

// --- Submit Handlers ---

async function handleSettingsSubmit(e) {
    e.preventDefault();
    
    State.apiKey = DOM.settingsApiKey.value.trim();
    State.embeddingModel = DOM.settingsEmbedModel.value;
    State.generationModel = DOM.settingsGenModel.value;
    State.topK = parseInt(DOM.settingsTopK.value);
    State.temperature = parseFloat(DOM.settingsTemperature.value);
    State.hybridWeight = parseFloat(DOM.settingsHybridWeight.value);
    
    saveLocalSettings();
    
    DOM.saveSettingsBtn.innerHTML = `<i class="fa-solid fa-spinner fa-spin mr-2"></i>Saving Configuration...`;
    
    try {
        const response = await fetch('/api/settings', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                apiKey: State.apiKey,
                embeddingModel: State.embeddingModel,
                generationModel: State.generationModel,
                temperature: State.temperature,
                topK: State.topK,
                hybridWeight: State.hybridWeight
            })
        });
        
        if (!response.ok) {
            const errData = await response.json();
            throw new Error(errData.detail || 'Settings sync failed');
        }
        
        DOM.saveSettingsBtn.className = 'w-full bg-emerald-600 text-white font-bold py-3.5 px-5 rounded-xl flex items-center justify-center gap-2 text-sm';
        DOM.saveSettingsBtn.innerHTML = `<i class="fa-solid fa-circle-check text-base"></i><span>Configuration Saved Successfully</span>`;
        
        setTimeout(() => {
            DOM.saveSettingsBtn.className = "w-full bg-neutral-200 hover:bg-neutral-300 text-neutral-900 font-bold py-3.5 px-5 rounded-xl cursor-pointer shadow-md transition hover:-translate-y-0.5 flex items-center justify-center gap-2 text-sm";
            DOM.saveSettingsBtn.innerHTML = `<i class="fa-solid fa-save text-base"></i><span>Save and Test Configuration</span>`;
        }, 2000);
        
        checkServerStatus(false);
    } catch (err) {
        console.error(err);
        alert(`Failed to save backend configuration: ${err.message}`);
        DOM.saveSettingsBtn.innerHTML = `<i class="fa-solid fa-save text-base"></i><span>Save and Test Configuration</span>`;
    }
}

async function handleIndexingSubmit(e) {
    e.preventDefault();
    
    if (!State.apiKey) {
        alert("An OpenRouter API key is required to build vector embeddings. Configure it in the 'API Settings' tab first.");
        switchTab('settings-view', document.getElementById('tab-btn-settings'));
        return;
    }
    
    const size = parseInt(DOM.configChunkSize.value);
    const overlap = parseInt(DOM.configChunkOverlap.value);
    
    if (overlap >= size) {
        alert("Chunk overlap cannot be greater than or equal to chunk size.");
        return;
    }
    
    DOM.startIndexingBtn.disabled = true;
    DOM.startIndexingBtn.innerHTML = `<i class="fa-solid fa-spinner fa-spin mr-2"></i>Initializing Indexing...`;
    
    try {
        const response = await fetch('/api/index', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                chunkSize: size,
                chunkOverlap: overlap
            })
        });
        
        if (!response.ok) {
            const err = await response.json();
            throw new Error(err.detail || 'Failed to start indexing pipeline');
        }
        
        const data = await response.json();
        if (data.status === 'started' || data.status === 'in_progress') {
            checkServerStatus(false);
        }
    } catch (err) {
        console.error(err);
        alert(`Indexing failed to initialize: ${err.message}`);
        DOM.startIndexingBtn.disabled = false;
        DOM.startIndexingBtn.innerHTML = `<i class="fa-solid fa-play-circle text-base"></i><span>Start Vector Training / Indexing</span>`;
    }
}

function handleFileUploadChange(e) {
    const file = e.target.files[0];
    if (file) {
        DOM.uploadFileLabel.textContent = file.name;
        DOM.uploadDocBtn.disabled = false;
        
        DOM.uploadStatusMsg.className = 'hidden mt-4 text-xs font-medium py-3 px-4 rounded-xl border flex items-center gap-2';
        DOM.uploadStatusMsg.innerHTML = '';
    } else {
        DOM.uploadFileLabel.textContent = "Select PDF or TXT File";
        DOM.uploadDocBtn.disabled = true;
    }
}

async function handleDocUploadSubmit() {
    const file = DOM.docUploadInput.files[0];
    if (!file) return;
    
    if (!State.apiKey) {
        alert("An OpenRouter API key is required to generate embeddings for supplementary documents. Configure it in settings first.");
        switchTab('settings-view', document.getElementById('tab-btn-settings'));
        return;
    }
    
    DOM.uploadDocBtn.disabled = true;
    DOM.uploadDocBtn.innerHTML = `<i class="fa-solid fa-spinner fa-spin mr-2"></i>Uploading...`;
    
    DOM.uploadStatusMsg.className = 'mt-4 text-xs font-medium py-3 px-4 rounded-xl border flex items-center gap-2 bg-sky-500/5 text-sky-400 border-sky-500/20';
    DOM.uploadStatusMsg.innerHTML = `<i class="fa-solid fa-circle-notch fa-spin text-sm"></i><span>Extracting text, computing dense embeddings, and updating FAISS index...</span>`;
    
    const formData = new FormData();
    formData.append('file', file);
    
    try {
        const response = await fetch('/api/upload', {
            method: 'POST',
            body: formData
        });
        
        if (!response.ok) {
            const errData = await response.json();
            throw new Error(errData.detail || 'Upload failed');
        }
        
        const data = await response.json();
        
        DOM.uploadStatusMsg.className = 'mt-4 text-xs font-medium py-3 px-4 rounded-xl border flex items-center gap-2 bg-emerald-500/5 text-emerald-400 border-emerald-500/20';
        DOM.uploadStatusMsg.innerHTML = `<i class="fa-solid fa-circle-check text-sm text-emerald-400"></i><span>Successfully indexed <strong>${data.chunks_added}</strong> new chunks. Total chunks in FAISS database is now <strong>${data.total_chunks}</strong>.</span>`;
        
        DOM.docUploadInput.value = '';
        DOM.uploadFileLabel.textContent = "Select PDF or TXT File";
        
        checkServerStatus(false);
        
    } catch (err) {
        console.error(err);
        DOM.uploadStatusMsg.className = 'mt-4 text-xs font-medium py-3 px-4 rounded-xl border flex items-center gap-2 bg-rose-500/5 text-rose-400 border-rose-500/20';
        DOM.uploadStatusMsg.innerHTML = `<i class="fa-solid fa-circle-exclamation text-sm text-rose-400"></i><span>Error: ${err.message}</span>`;
    } finally {
        DOM.uploadDocBtn.innerHTML = `<i class="fa-solid fa-upload"></i><span>Upload and Index</span>`;
    }
}

async function handleExplorerSearchSubmit(e) {
    e.preventDefault();
    const query = DOM.explorerSearchInput.value.trim();
    if (!query) return;
    
    if (!State.indexed) {
        alert("Please run vector training and indexing in the 'Document Indexer' tab first.");
        return;
    }
    
    DOM.explorerResultsGrid.innerHTML = `
        <div class="no-results-placeholder text-center py-14 text-slate-500">
            <i class="fa-solid fa-spinner fa-spin text-4xl mb-4 text-sky-400"></i>
            <p class="text-sm">Searching vector index files and matching hybrid parameters...</p>
        </div>
    `;
    DOM.resultsCountBanner.classList.add('hidden');
    
    try {
        const response = await fetch('/api/search', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                query: query,
                topK: State.topK,
                hybridWeight: State.hybridWeight
            })
        });
        
        if (!response.ok) throw new Error('Search request failed');
        
        const data = await response.json();
        renderExplorerResults(data.results);
    } catch (err) {
        console.error(err);
        DOM.explorerResultsGrid.innerHTML = `
            <div class="no-results-placeholder text-center py-14 text-red-400">
                <i class="fa-solid fa-circle-exclamation text-4xl mb-4"></i>
                <p class="text-sm">Retrieval search failed. If dense search is active, ensure your OpenRouter key is correct.</p>
            </div>
        `;
    }
}

function renderExplorerResults(results) {
    DOM.explorerResultsGrid.innerHTML = '';
    
    if (!results || results.length === 0) {
        DOM.explorerResultsGrid.innerHTML = `
            <div class="no-results-placeholder text-center py-14 text-slate-500">
                <i class="fa-solid fa-magnifying-glass-minus text-4xl mb-4 opacity-35"></i>
                <p class="text-sm">No matching passages found inside indexed textbook pages.</p>
            </div>
        `;
        return;
    }
    
    DOM.resultsCountText.textContent = results.length;
    DOM.resultsCountBanner.classList.remove('hidden');
    
    results.forEach(item => {
        const card = document.createElement('article');
        card.className = 'result-card bg-neutral-900 border border-white/10 rounded-2xl p-5 shadow-xl flex flex-col gap-3 animate-slideIn';
        
        const pct = Math.round(item.similarity_score * 100);
        
        card.innerHTML = `
            <div class="result-card-header flex justify-between items-center mb-1 select-none">
                <span class="result-page-tag bg-neutral-800 border border-white/5 text-[#a1a1a1] py-1.5 px-3 rounded-lg text-xs font-semibold flex items-center gap-1.5"><i class="fa-solid fa-file-invoice"></i>Page ${item.page_start}</span>
                <div class="similarity-bar-container flex items-center gap-2.5">
                    <span class="score-badge text-xs font-bold text-emerald-400">${pct}% match</span>
                    <div class="mini-score-bar w-14 h-1.5 bg-white/5 rounded-full overflow-hidden">
                        <div class="mini-score-fill h-full bg-emerald-500 rounded-full" style="width: ${pct}%;"></div>
                    </div>
                </div>
            </div>
            <div class="result-card-content text-sm text-slate-300 italic leading-relaxed select-text">
                "${highlightQuery(item.text, DOM.explorerSearchInput.value)}"
            </div>
            <div class="result-card-footer flex items-center gap-4 text-[10px] text-slate-500 font-medium border-t border-white/5 pt-3.5 mt-1 select-none">
                <span>Dense Vector Score: <strong class="text-slate-400">${item.dense_score.toFixed(3)}</strong></span>
                <span>Sparse TF-IDF Score: <strong class="text-slate-400">${item.sparse_score.toFixed(3)}</strong></span>
                <span>Chars: <strong class="text-slate-400">${item.char_count}</strong></span>
            </div>
        `;
        DOM.explorerResultsGrid.appendChild(card);
    });
}

function highlightQuery(text, query) {
    const terms = query.toLowerCase().split(/\s+/).filter(t => t.length > 3);
    if (terms.length === 0) return text;
    
    let highlighted = text;
    terms.forEach(term => {
        try {
            const regex = new RegExp(`\\b(${term})\\b`, 'gi');
            highlighted = highlighted.replace(regex, '<mark>$1</mark>');
        } catch(e) {}
    });
    return highlighted;
}

// --- Conversational Chat logic ---

async function handleChatSubmit(e) {
    e.preventDefault();
    const query = DOM.chatInput.value.trim();
    if (!query) return;
    
    if (!State.indexed) {
        alert("The AI textbook is not indexed. Go to the 'Document Indexer' tab and build the index first.");
        return;
    }
    
    if (!State.apiKey) {
        alert("Your OpenRouter API Key is missing. Go to the 'API Settings' tab and save your key first.");
        switchTab('settings-view', document.getElementById('tab-btn-settings'));
        return;
    }
    
    // Clear input & disable button
    DOM.chatInput.value = '';
    DOM.chatInput.style.height = '40px';
    DOM.chatSendBtn.disabled = true;
    
    // Remove welcome splash if visible
    const welcome = DOM.chatScroller.querySelector('.assistant-welcome');
    if (welcome) welcome.remove();
    
    // Append User Message bubble
    appendMessage('user', query, null, true);
    
    // Create & Append Assistant Typing Indicator bubble
    const typingBubbleId = appendTypingIndicator();
    scrollToBottom();
    
    try {
        const response = await fetch('/api/chat', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                query: query,
                history: State.chatHistory,
                generationModel: State.generationModel,
                temperature: State.temperature,
                topK: State.topK,
                hybridWeight: State.hybridWeight
            })
        });
        
        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.detail || 'Chat completion request failed');
        }
        
        const data = await response.json();
        
        // Remove typing indicator & append actual response
        removeTypingIndicator(typingBubbleId);
        
        appendMessage('assistant', data.answer, {
            model: data.model,
            prompt_tokens: data.prompt_tokens,
            completion_tokens: data.completion_tokens,
            retrieved_chunks: data.retrieved_chunks
        }, true);
        
    } catch (err) {
        console.error(err);
        removeTypingIndicator(typingBubbleId);
        appendMessage('assistant', `⚠️ **Error**: Failed to generate a response from OpenRouter API. Let's make sure your API credentials are correct in the Settings. Details: *${err.message}*`, null, true);
    } finally {
        DOM.chatSendBtn.disabled = false;
        scrollToBottom();
    }
}

// Append bubble to scroller DOM (Perfect React Spec Aligned translation)
function appendMessage(role, text, metadata = null, shouldSave = false) {
    const bubble = document.createElement('div');
    const isUser = role === 'user';
    
    // Aligns layout container exactly
    bubble.className = `flex w-full select-text animate-slideIn ${
        isUser ? 'justify-end' : 'justify-start'
    }`;
    
    // Avatar markup block
    let avatarFallback = '';
    let avatarClass = '';
    if (isUser) {
        avatarFallback = 'JD';
        avatarClass = 'bg-neutral-800 text-neutral-50 text-xs leading-4';
    } else {
        avatarFallback = '<i class="fa-solid fa-sparkles text-[10px]"></i>';
        avatarClass = 'bg-neutral-200 text-neutral-900 flex justify-center items-center';
    }
    
    const avatarHtml = `
        <div class="size-8 rounded-full flex-shrink-0 flex items-center justify-center font-bold select-none ${avatarClass}">
            ${avatarFallback}
        </div>
    `;
    
    const parsedText = parseTextMarkup(text);
    
    // Formatting bubble bubble containers
    let bubbleContent = '';
    if (isUser) {
        bubbleContent = `
            <div class="max-w-[80%] flex items-end gap-3 select-text">
                <div class="rounded-tl-2xl rounded-tr-2xl rounded-bl-2xl rounded-br-sm bg-neutral-800 text-neutral-50 text-sm leading-5 px-4 py-3 select-text">
                    ${parsedText}
                </div>
                ${avatarHtml}
            </div>
        `;
    } else {
        let actionIcons = `
            <div class="flex pl-11 items-center gap-1 select-none mt-1.5">
                <button class="size-7 text-[#a1a1a1] hover:text-white rounded flex items-center justify-center hover:bg-white/5 transition cursor-pointer copy-btn" title="Copy"><i class="fa-regular fa-copy text-[11px]"></i></button>
                <button class="size-7 text-[#a1a1a1] hover:text-white rounded flex items-center justify-center hover:bg-white/5 transition cursor-pointer" title="Thumbs Up"><i class="fa-regular fa-thumbs-up text-[11px]"></i></button>
                <button class="size-7 text-[#a1a1a1] hover:text-white rounded flex items-center justify-center hover:bg-white/5 transition cursor-pointer" title="Thumbs Down"><i class="fa-regular fa-thumbs-down text-[11px]"></i></button>
                <button class="size-7 text-[#a1a1a1] hover:text-white rounded flex items-center justify-center hover:bg-white/5 transition cursor-pointer" title="Regenerate"><i class="fa-solid fa-arrows-rotate text-[11px]"></i></button>
            </div>
        `;
        
        let citationsBlock = '';
        if (metadata && metadata.retrieved_chunks && metadata.retrieved_chunks.length > 0) {
            const uniqueId = `cite-toggle-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`;
            const containerId = `cite-container-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`;
            
            const citationsListHtml = metadata.retrieved_chunks.map(chunk => `
                <div class="bg-white/2 border border-white/5 p-3 rounded-xl text-xs flex flex-col gap-1.5">
                    <div class="flex justify-between items-center text-[10px] font-bold text-sky-400 uppercase tracking-wide">
                        <span>Source: Page ${chunk.page_start}</span>
                        <span>Match: ${Math.round(chunk.similarity_score * 100)}%</span>
                    </div>
                    <div class="text-[#a1a1a1] italic">
                        "${chunk.text.substring(0, 300)}..."
                    </div>
                </div>
            `).join('');
            
            citationsBlock = `
                <div class="mt-3 border-t border-white/10 pt-2.5 w-full select-none">
                    <button type="button" class="flex items-center gap-2 text-xs font-semibold text-[#a1a1a1] hover:text-sky-400 transition cursor-pointer" id="${uniqueId}">
                        <i class="fa-solid fa-book-open text-[11px]"></i> 
                        <span>View Retrieved Textbook Sources (${metadata.retrieved_chunks.length})</span>
                    </button>
                    <div class="flex flex-col gap-2 mt-3.5 hidden select-text cite-list-block" id="${containerId}">
                        ${citationsListHtml}
                    </div>
                </div>
                
                <div class="chat-response-meta flex items-center gap-3.5 mt-2.5 text-[10px] text-slate-500 font-semibold select-none">
                    <span>Model: <strong>${metadata.model.split('/').pop()}</strong></span>
                    <span>Prompt: <strong>${metadata.prompt_tokens} tokens</strong></span>
                    <span>Gen: <strong>${metadata.completion_tokens} tokens</strong></span>
                </div>
            `;
        }
        
        bubbleContent = `
            <div class="max-w-[85%] flex flex-col gap-1 select-text">
                <div class="flex items-start gap-3 select-text">
                    ${avatarHtml}
                    <div class="leading-relaxed rounded-tl-sm rounded-tr-2xl rounded-bl-2xl rounded-br-2xl bg-neutral-900 text-neutral-50 text-sm leading-5 border-white/10 border border-solid px-4 py-3 select-text">
                        <div class="msg-text-content select-text">${parsedText}</div>
                        ${citationsBlock}
                    </div>
                </div>
                ${actionIcons}
            </div>
        `;
    }
    
    bubble.innerHTML = bubbleContent;
    DOM.chatScroller.appendChild(bubble);
    
    // Bind dynamic citation toggle action
    if (!isUser && metadata && metadata.retrieved_chunks && metadata.retrieved_chunks.length > 0) {
        const toggleBtn = bubble.querySelector('.mt-3 button');
        const listBlock = bubble.querySelector('.cite-list-block');
        if (toggleBtn && listBlock) {
            toggleBtn.addEventListener('click', () => {
                listBlock.classList.toggle('hidden');
                const isOpen = !listBlock.classList.contains('hidden');
                toggleBtn.querySelector('span').textContent = isOpen 
                    ? `Hide Retrieved Textbook Sources` 
                    : `View Retrieved Textbook Sources (${metadata.retrieved_chunks.length})`;
            });
        }
    }
    
    // Bind copy icon action
    if (!isUser) {
        const copyBtn = bubble.querySelector('.copy-btn');
        if (copyBtn) {
            copyBtn.addEventListener('click', () => {
                navigator.clipboard.writeText(text);
                const icon = copyBtn.querySelector('i');
                icon.className = "fa-solid fa-check text-emerald-400 text-xs";
                setTimeout(() => {
                    icon.className = "fa-regular fa-copy text-xs";
                }, 2000);
            });
        }
    }

    // Bind thumbs up/down feedback actions
    if (!isUser) {
        const thumbsUpBtn = bubble.querySelector('[title="Thumbs Up"]');
        const thumbsDownBtn = bubble.querySelector('[title="Thumbs Down"]');
        
        if (thumbsUpBtn && thumbsDownBtn && metadata && metadata.retrieved_chunks) {
            const chunkIds = metadata.retrieved_chunks.map(c => c.id);
            
            thumbsUpBtn.addEventListener('click', () => {
                const lastUserMsg = [...State.chatHistory].reverse().find(m => m.role === 'user');
                const query = lastUserMsg ? lastUserMsg.content : '';
                if (!query) return;
                
                submitUserFeedback(query, chunkIds, 1, thumbsUpBtn, thumbsDownBtn);
            });
            
            thumbsDownBtn.addEventListener('click', () => {
                const lastUserMsg = [...State.chatHistory].reverse().find(m => m.role === 'user');
                const query = lastUserMsg ? lastUserMsg.content : '';
                if (!query) return;
                
                submitUserFeedback(query, chunkIds, -1, thumbsUpBtn, thumbsDownBtn);
            });
        }
    }
    
    // Save to history list & localStorage if needed
    if (shouldSave) {
        State.chatHistory.push({ role: role, content: text, metadata: metadata });
        saveActiveConversation();
    }
    
    scrollToBottom();
}

function appendTypingIndicator() {
    const bubbleId = `typing-${Date.now()}`;
    const bubble = document.createElement('div');
    bubble.className = 'flex justify-start w-full animate-slideIn select-none';
    bubble.id = bubbleId;
    
    bubble.innerHTML = `
        <div class="max-w-[85%] flex flex-col gap-1 select-none">
            <div class="flex items-start gap-3 select-none">
                <div class="size-8 rounded-full bg-neutral-200 text-neutral-900 flex justify-center items-center flex-shrink-0 select-none">
                    <i class="fa-solid fa-sparkles text-[10px]"></i>
                </div>
                <div class="leading-relaxed rounded-tl-sm rounded-tr-2xl rounded-bl-2xl rounded-br-2xl bg-neutral-900 text-neutral-50 text-sm leading-5 border-white/10 border border-solid px-4.5 py-4 flex items-center shadow-md">
                    <div class="flex items-center gap-1">
                        <div class="w-1.5 h-1.5 bg-slate-400 rounded-full animate-bounce [animation-delay:-0.3s]"></div>
                        <div class="w-1.5 h-1.5 bg-slate-400 rounded-full animate-bounce [animation-delay:-0.15s]"></div>
                        <div class="w-1.5 h-1.5 bg-slate-400 rounded-full animate-bounce"></div>
                    </div>
                </div>
            </div>
        </div>
    `;
    DOM.chatScroller.appendChild(bubble);
    return bubbleId;
}

function removeTypingIndicator(id) {
    const element = document.getElementById(id);
    if (element) element.remove();
}

function scrollToBottom() {
    DOM.chatScroller.scrollTop = DOM.chatScroller.scrollHeight;
}

// --- Markdown and Custom Citation Parser ---
function parseTextMarkup(text) {
    let html = text;
    
    // 1. Escaping basic HTML to prevent injection
    html = html
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;");
        
    // 2. Parse code blocks: ```code```
    html = html.replace(/```([\s\S]*?)```/g, '<pre><code>$1</code></pre>');
    
    // 3. Parse inline code backticks: `code`
    html = html.replace(/`([^`]+)`/g, '<code>$1</code>');
    
    // 4. Parse bold markdown: **text**
    html = html.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');
    
    // 5. Parse italic markdown: *text*
    html = html.replace(/\*([^*]+)\*/g, '<em>$1</em>');
    
    // 6. Custom conversion of [Page X] markers to styled components
    html = html.replace(/\[Page\s+(\d+)\]/g, '<span class="book-citation" title="Cited from page $1 of AI: A Modern Approach"><i class="fa-solid fa-file-lines"></i> Page $1</span>');
    html = html.replace(/\[Source:\s+Page\s+(\d+)\]/g, '<span class="book-citation" title="Cited from page $1 of AI: A Modern Approach"><i class="fa-solid fa-file-lines"></i> Page $1</span>');

    // 7. Parse bullet points: lines starting with "- " or "* "
    html = html.split('\n').map(line => {
        const clean = line.trim();
        if (clean.startsWith('- ') || clean.startsWith('* ')) {
            return `<li>${clean.substring(2)}</li>`;
        }
        return line;
    }).join('\n');
    
    // Wrap lists in ul
    html = html.replace(/(<li>[\s\S]*?<\/li>)/g, '<ul>$1</ul>');
    // Clean nested ul repetitions
    html = html.replace(/<\/ul>\n<ul>/g, '\n');

    // 8. Paragraph carriage returns
    html = html.replace(/\n\n/g, '<br><br>');
    
    return html;
}

async function submitUserFeedback(query, chunkIds, val, upBtn, downBtn) {
    try {
        const response = await fetch('/api/feedback', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                query: query,
                chunkIds: chunkIds,
                feedback: val
            })
        });
        
        if (!response.ok) throw new Error('Feedback sync failed');
        
        const upIcon = upBtn.querySelector('i');
        const downIcon = downBtn.querySelector('i');
        
        if (val === 1) {
            upIcon.className = "fa-solid fa-thumbs-up text-emerald-400 text-[11px]";
            downIcon.className = "fa-regular fa-thumbs-down text-[#a1a1a1] text-[11px]";
        } else {
            upIcon.className = "fa-regular fa-thumbs-up text-[#a1a1a1] text-[11px]";
            downIcon.className = "fa-solid fa-thumbs-down text-rose-400 text-[11px]";
        }
    } catch (e) {
        console.error('Feedback error:', e);
    }
}
